/*
Navicat MySQL Data Transfer

Source Server         : 5.9.156.56:3306
Source Server Version : 50536
Source Host           : 5.9.156.56:3306
Source Database       : arma3life_13

Target Server Type    : MYSQL
Target Server Version : 50536
File Encoding         : 65001

Date: 2014-07-13 15:33:12
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `alc_groups`
-- ----------------------------
DROP TABLE IF EXISTS `alc_groups`;
CREATE TABLE `alc_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT 'gast',
  `color` varchar(7) NOT NULL DEFAULT '#000000',
  `permissions` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_groups
-- ----------------------------
INSERT INTO alc_groups VALUES ('1', 'guest', '#A9A9A9', '');
INSERT INTO alc_groups VALUES ('2', 'admin', '#DC143C', '*');
INSERT INTO alc_groups VALUES ('3', 'member', '#FFA500', '');
INSERT INTO alc_groups VALUES ('4', 'moderator', '#32CD32', '0,1,2,3');
INSERT INTO alc_groups VALUES ('5', 'user', '#87CEEB', '');

-- ----------------------------
-- Table structure for `alc_ipcheck`
-- ----------------------------
DROP TABLE IF EXISTS `alc_ipcheck`;
CREATE TABLE `alc_ipcheck` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL DEFAULT '000.000.000.000',
  `userid` int(11) NOT NULL DEFAULT '0',
  `what` varchar(100) NOT NULL DEFAULT '',
  `time` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `what` (`what`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_ipcheck
-- ----------------------------

-- ----------------------------
-- Table structure for `alc_navigation`
-- ----------------------------
DROP TABLE IF EXISTS `alc_navigation`;
CREATE TABLE `alc_navigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) NOT NULL DEFAULT '0',
  `katid` int(11) NOT NULL DEFAULT '0',
  `shown` int(1) NOT NULL DEFAULT '1',
  `name` text,
  `url` text,
  `target` varchar(20) NOT NULL DEFAULT '_self',
  `internal` int(1) NOT NULL DEFAULT '0',
  `wichtig` int(1) NOT NULL DEFAULT '0',
  `permission` varchar(100) NOT NULL DEFAULT '',
  `page` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_navigation
-- ----------------------------
INSERT INTO alc_navigation VALUES ('1', '0', '4', '1', 'Basic Form Elements', 'form-elements.html', '_self', '0', '0', 'nav_test', '0');
INSERT INTO alc_navigation VALUES ('2', '1', '4', '1', 'Form Components', 'form-components.html', '_self', '0', '0', '', '0');
INSERT INTO alc_navigation VALUES ('3', '2', '4', '1', 'Form Examples', 'form-examples.html', '_self', '0', '0', '', '0');
INSERT INTO alc_navigation VALUES ('4', '3', '4', '1', 'Form Validation', 'form-validation.html', '_self', '0', '0', '', '0');

-- ----------------------------
-- Table structure for `alc_navigation_kategorie`
-- ----------------------------
DROP TABLE IF EXISTS `alc_navigation_kategorie`;
CREATE TABLE `alc_navigation_kategorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `img` varchar(200) NOT NULL DEFAULT '',
  `class` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `target` varchar(20) NOT NULL DEFAULT '_self',
  `shown` int(1) NOT NULL DEFAULT '1',
  `internal` int(1) NOT NULL DEFAULT '0',
  `wichtig` int(1) NOT NULL DEFAULT '0',
  `permission` varchar(100) NOT NULL DEFAULT '',
  `page` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_navigation_kategorie
-- ----------------------------
INSERT INTO alc_navigation_kategorie VALUES ('1', 'Dashboard', '', 'sa-side-home', 'index.html', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('2', 'Typography', '', 'sa-side-typography', 'typography.html', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('3', 'Widgets', '', 'sa-side-widget', 'content-widgets.html', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('4', 'Form', '', 'sa-side-form', '', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('5', 'User Interface', '', 'sa-side-ui', '', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('6', 'CHARTS', '', 'sa-side-chart', '', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('7', 'Calendar', '', 'sa-side-calendar', '', '_self', '1', '0', '0', '', '0');
INSERT INTO alc_navigation_kategorie VALUES ('8', 'Pages', '', 'sa-side-page', '', '_self', '1', '0', '0', '', '0');

-- ----------------------------
-- Table structure for `alc_permissions`
-- ----------------------------
DROP TABLE IF EXISTS `alc_permissions`;
CREATE TABLE `alc_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT 'perm_news_comments',
  `permission` varchar(100) NOT NULL DEFAULT 'news_comments',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_permissions
-- ----------------------------
INSERT INTO alc_permissions VALUES ('1', 'perm_nav_test', 'nav_test');

-- ----------------------------
-- Table structure for `alc_settings`
-- ----------------------------
DROP TABLE IF EXISTS `alc_settings`;
CREATE TABLE `alc_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(200) NOT NULL DEFAULT '',
  `value` text,
  `default` text,
  `length` int(11) NOT NULL DEFAULT '1',
  `type` varchar(20) NOT NULL DEFAULT 'int' COMMENT 'int/string',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_settings
-- ----------------------------
INSERT INTO alc_settings VALUES ('1', 'tmpdir', 'standard', 'standard', '0', 'string');
INSERT INTO alc_settings VALUES ('2', 'language', 'de', 'de', '0', 'string');

-- ----------------------------
-- Table structure for `alc_users`
-- ----------------------------
DROP TABLE IF EXISTS `alc_users`;
CREATE TABLE `alc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT 'username',
  `pid` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `sessid` varchar(60) NOT NULL DEFAULT '',
  `userip` varchar(15) NOT NULL DEFAULT '000.000.000.000',
  `permid` varchar(60) NOT NULL DEFAULT '',
  `online` int(1) NOT NULL DEFAULT '0',
  `enabled` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL DEFAULT '0',
  `country` varchar(6) NOT NULL DEFAULT 'de',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_users
-- ----------------------------
INSERT INTO alc_users VALUES ('1', 'test', '00000000', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', '', '', '', '0', '1', '0', 'de');

-- ----------------------------
-- Table structure for `alc_users_groups`
-- ----------------------------
DROP TABLE IF EXISTS `alc_users_groups`;
CREATE TABLE `alc_users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_users_groups
-- ----------------------------
INSERT INTO alc_users_groups VALUES ('1', '1', '2');

-- ----------------------------
-- Table structure for `alc_users_permissions`
-- ----------------------------
DROP TABLE IF EXISTS `alc_users_permissions`;
CREATE TABLE `alc_users_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissions` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_users_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for `alc_users_stats`
-- ----------------------------
DROP TABLE IF EXISTS `alc_users_stats`;
CREATE TABLE `alc_users_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logins` int(11) NOT NULL DEFAULT '0',
  `last_online` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alc_users_stats
-- ----------------------------
INSERT INTO alc_users_stats VALUES ('1', '15', '1404038822');

-- ----------------------------
-- Table structure for `houses`
-- ----------------------------
DROP TABLE IF EXISTS `houses`;
CREATE TABLE `houses` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `house_id` varchar(32) NOT NULL,
  `pid` varchar(32) NOT NULL,
  `storage` varchar(255) NOT NULL,
  `trunk` varchar(2048) NOT NULL DEFAULT '[]',
  `weapon_storage` varchar(4096) NOT NULL DEFAULT '[]',
  `weapon_storage2` varchar(4096) NOT NULL DEFAULT '[]',
  `position` varchar(255) NOT NULL,
  `occupied` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `house_id` (`house_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of houses
-- ----------------------------
INSERT INTO houses VALUES ('3', '449315', '76561197979236723', '\"[]\"', '\"[[],0]\"', '[]', '[]', '\"[14250,18556,0.0235519]\"', '1', '0');
INSERT INTO houses VALUES ('4', '449316', '76561197979236723', '\"[]\"', '\"[[],0]\"', '[]', '[]', '\"[14246.5,18574.6,0.308229]\"', '1', '0');

-- ----------------------------
-- Table structure for `players`
-- ----------------------------
DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
  `uid` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `playerid` varchar(50) NOT NULL,
  `cash` int(100) NOT NULL DEFAULT '0',
  `bankacc` int(100) NOT NULL DEFAULT '0',
  `coplevel` enum('0','1','2','3','4','5','6','7') NOT NULL DEFAULT '0',
  `cop_licenses` text,
  `civ_licenses` text,
  `med_licenses` text,
  `cop_gear` text NOT NULL,
  `mediclevel` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `arrested` tinyint(1) NOT NULL DEFAULT '0',
  `aliases` text NOT NULL,
  `adminlevel` enum('0','1','2','3') NOT NULL DEFAULT '0',
  `donatorlvl` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `civ_gear` text NOT NULL,
  `blacklist` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `playerid` (`playerid`),
  KEY `name` (`name`),
  KEY `blacklist` (`blacklist`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of players
-- ----------------------------
INSERT INTO players VALUES ('24', '[REV]Pictureclass', '76561198066153753', '0', '238440', '7', '\"[[`license_cop_air`,0],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,1],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,1]]\"', '\"[`arifle_MXC_F`,`hgun_P07_snds_F`,[`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_TacVest_blk`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`Binocular`,`H_Beret_blk_POLICE`],[``,`acc_flashlight`,`optic_Arco`],[],[`muzzle_snds_L`,``,``],[`FirstAidKit`,`ItemCompass`,`16Rnd_9x21_Mag`,`SmokeShell`],[`FirstAidKit`,`U_Rangemaster`,`SmokeShell`,`SmokeShell`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`],[`ToolKit`,`ToolKit`,`ToolKit`,`FirstAidKit`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`SmokeShell`]]\"', '5', '0', '\"[`[REV]Pictureclass`]\"', '0', '5', '\"[``,``,[],`U_IG_Guerilla2_3`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`],[],[],[],[`FirstAidKit`],[],[]]\"', '0');
INSERT INTO players VALUES ('25', 'Hannes', '76561197987010708', '1718', '346646', '7', '\"[[`license_cop_air`,1],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,1],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[[`license_med_air`,1]]\"', '\"[`arifle_MXC_F`,`hgun_P07_snds_F`,[`30Rnd_65x39_caseless_mag`,`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_Rangemaster_belt`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`NVGoggles`,`Binocular`],[``,``,`optic_Arco`],[],[`muzzle_snds_L`,``,``],[`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`],[`FirstAidKit`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`],[`ToolKit`,`FirstAidKit`,`FirstAidKit`,`FirstAidKit`,`SmokeShell`,`SmokeShell`,`SmokeShell`,`SmokeShell`,`SmokeShell`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`]]\"', '5', '0', '\"[`Hannes`]\"', '3', '5', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`NVGoggles`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('26', '[JKnF] Jens', '76561198065064254', '0', '127957', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[JKnF] Jens`]\"', '0', '3', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`],[],[],[],[],[],[`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('27', '[KdS] Black Bull', '76561197979236723', '2', '687305', '2', '\"[[`license_cop_air`,0],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,1],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,1],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,1],[`license_civ_rebel`,1],[`license_civ_coke`,1],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,1],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,1]]\"', '\"[`SMG_02_ACO_F`,`hgun_P07_snds_F`,[`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_Rangemaster_belt`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`NVGoggles`,`Binocular`,`G_Shades_Black`],[`muzzle_snds_L`,``,`optic_ACO_grn_smg`],[],[`muzzle_snds_L`,``,``],[`ItemGPS`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`],[`ItemGPS`,`16Rnd_9x21_Mag`,`20Rnd_556x45_UW_mag`,`20Rnd_556x45_UW_mag`,`20Rnd_556x45_UW_mag`,`30Rnd_9x21_Mag`,`SmokeShell`],[`FirstAidKit`,`ToolKit`,`ToolKit`,`ToolKit`,`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`]]\"', '2', '0', '\"[`Herr Graf`]\"', '0', '3', '\"[`arifle_TRG20_F`,``,[`30Rnd_556x45_Stanag`],`U_O_GhillieSuit`,`V_TacVest_khk`,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`Binocular`],[``,``,`optic_Hamr`],[],[],[`FirstAidKit`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`],[`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`],[`ToolKit`,`ToolKit`,`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('28', 'Spezialeinheit', '76561198050174817', '0', '9209097', '7', '\"[[`license_cop_air`,1],[`license_cop_swat`,0],[`license_cop_cg`,1]]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,0]]\"', '\"[`arifle_MX_F`,`hgun_P07_snds_F`,[`30Rnd_65x39_caseless_mag`,`16Rnd_9x21_Mag`],`U_B_CombatUniform_mcam_vest`,`V_PlateCarrierIAGL_dgtl`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`NVGoggles`,`Binocular`,`H_Beret_blk_POLICE`],[``,`acc_flashlight`,`optic_Holosight`],[],[`muzzle_snds_L`,``,``],[`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`],[`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`],[`ToolKit`,`ToolKit`,`FirstAidKit`,`FirstAidKit`,`ToolKit`,`FirstAidKit`,`FirstAidKit`,`SmokeShell`,`SmokeShell`,`SmokeShell`,`SmokeShell`,`Chemlight_blue`,`Chemlight_blue`,`Chemlight_blue`,`Chemlight_yellow`,`Chemlight_yellow`,`Chemlight_blue`,`Chemlight_blue`,`Chemlight_yellow`,`Chemlight_red`,`Chemlight_yellow`,`Chemlight_red`,`Chemlight_yellow`,`SmokeShell`]]\"', '5', '0', '\"[`Spezialeinheit`]\"', '3', '5', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`Binocular`],[],[],[],[`ItemCompass`],[],[]]\"', '0');
INSERT INTO players VALUES ('29', '[JKnF] Centinel', '76561198101824673', '0', '39180', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[JKnF] Centinel`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('30', 'LeDerHosnBob', '76561198074646183', '568165', '7000', '2', '\"[[`license_cop_air`,0],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,1],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,1],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,0]]\"', '\"[``,`hgun_P07_snds_F`,[`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_Rangemaster_belt`,``,[`ItemMap`,`ItemCompass`,`NVGoggles`,`H_Booniehat_mcamo`],[],[],[`muzzle_snds_L`,``,``],[`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`],[`16Rnd_9x21_Mag`],[]]\"', '5', '0', '\"[`LeDerHosnBob`]\"', '0', '3', '\"[`arifle_Mk20C_plain_F`,``,[`30Rnd_556x45_Stanag`],`U_C_Poloshirt_stripped`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`G_Aviator`],[``,``,`optic_ACO_grn_smg`],[],[],[`30Rnd_556x45_Stanag`],[],[`ToolKit`,`ToolKit`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`,`30Rnd_556x45_Stanag`]]\"', '0');
INSERT INTO players VALUES ('31', 'Max Muster', '76561198099413428', '0', '10000', '0', '\"[]\"', '\"[]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Max Muster`]\"', '0', '0', '\"[]\"', '0');
INSERT INTO players VALUES ('33', 'Jack', '76561198078264584', '23500', '2428373', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,1],[`license_civ_rebel`,1],[`license_civ_coke`,1],[`license_civ_diamond`,0],[`license_civ_copper`,1],[`license_civ_iron`,0],[`license_civ_sand`,1],[`license_civ_salt`,1],[`license_civ_cement`,0],[`license_civ_home`,1],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,1]]\"', '\"[]\"', '0', '0', '\"[`Jack`]\"', '0', '0', '\"[``,``,[],`U_C_Driver_1_white`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`G_Aviator`],[],[],[],[`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`],[],[`ToolKit`,`NVGoggles`,`V_TacVest_khk`,`H_RacingHelmet_4_F`]]\"', '0');
INSERT INTO players VALUES ('34', '[SotD] Fatal1ty', '76561198057675199', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[SotD] Fatal1ty`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('35', '[Chief] Audacious', '76561197963820270', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[Chief] Audacious`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('37', 'Magic', '76561198081645574', '0', '36895', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[[`license_med_air`,0]]\"', '\"[]\"', '0', '0', '\"[`Magic`]\"', '0', '0', '\"[``,``,[],`U_IG_Guerilla3_1`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`G_Sport_BlackWhite`],[],[],[],[],[],[`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('38', '[C.R.A.P.D.] King_Moe', '76561198123978953', '0', '10000', '0', '\"[]\"', '\"[]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[C.R.A.P.D.] King_Moe`]\"', '0', '0', '\"[]\"', '0');
INSERT INTO players VALUES ('39', 'Dominik', '76561197973626204', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Dominik`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('40', 'Gerhard', '76561198007506270', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Gerhard`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('41', 'scugnizzo', '76561198065632926', '638', '44000', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`scugnizzo`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`G_Squares`],[],[],[],[],[],[`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('42', 'Boroghor', '76561198012241252', '37519', '8425', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,1],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Boroghor`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('43', 'Torsten', '76561197971220567', '5000', '1445655', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,1],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,1],[`license_civ_rebel`,0],[`license_civ_coke`,1],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,1],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Torsten`]\"', '0', '0', '\"[``,`hgun_ACPC2_F`,[`9Rnd_45ACP_Mag`],`U_C_Poloshirt_blue`,`V_Rangemaster_belt`,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`Binocular`],[],[],[``,``,``],[`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`],[`FirstAidKit`,`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`,`9Rnd_45ACP_Mag`],[`ToolKit`,`ToolKit`,`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('44', 'Elfik', '76561198016821081', '3807', '72490', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,1],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,1],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Elfik`]\"', '0', '0', '\"[``,`hgun_ACPC2_F`,[`9Rnd_45ACP_Mag`],`U_NikosAgedBody`,`V_Rangemaster_belt`,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`G_Spectacles_Tinted`],[],[],[``,``,``],[`G_Spectacles_Tinted`,`30Rnd_9x21_Mag`,`9Rnd_45ACP_Mag`],[`FirstAidKit`,`FirstAidKit`,`30Rnd_9x21_Mag`,`30Rnd_9x21_Mag`],[`ToolKit`,`ToolKit`,`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('46', '[JKnF] WeeDStaR', '76561198033568630', '5000', '571463', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[JKnF] WeeDStaR`]\"', '0', '0', '\"[`arifle_TRG20_F`,``,[`30Rnd_556x45_Stanag`],`U_C_Driver_1`,`V_TacVest_blk`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`],[``,``,`optic_Hamr`],[],[],[`FirstAidKit`,`16Rnd_9x21_Mag`],[`FirstAidKit`,`FirstAidKit`,`FirstAidKit`,`SmokeShell`,`SmokeShell`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`SmokeShell`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`,`SmokeShell`],[`ToolKit`,`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('47', 'D3r_G3cKo', '76561198058274216', '0', '40507', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`D3r_G3cKo`]\"', '0', '0', '\"[``,``,[],`U_IG_Guerilla2_3`,``,`B_Carryall_oli`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`NVGoggles`,`Binocular`,`G_Squares`,`H_Hat_tan`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('48', '[JKnF]OnCue', '76561198067561069', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[JKnF]OnCue`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('49', '(VG)Anton', '76561198124879688', '0', '15000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`(VG)Anton`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('50', '[VG]Majestic', '76561198101092359', '0', '15000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[VG]Majestic`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('51', 'Geonavi', '76561198098700673', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Geonavi`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('52', 'Travis Martinez', '76561198085848196', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Travis Whitfield`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('53', 'Mike', '76561198087088257', '0', '10000', '0', '\"[[`license_cop_air`,0],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[]\"', '\"[]\"', '\"[``,`hgun_P07_snds_F`,[`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_Rangemaster_belt`,``,[`ItemMap`,`ItemCompass`],[],[],[`muzzle_snds_L`,``,``],[`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`],[`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`],[]]\"', '0', '0', '\"[`Mike`]\"', '0', '0', '\"[]\"', '0');
INSERT INTO players VALUES ('54', 'IceSrb', '76561198058821513', '4000', '2000', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`IceSrb`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,`B_AssaultPack_cbr`,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('55', 'SkyGlass', '76561198036235168', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`SkyGlass`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('56', '[k1nGz]dERP', '76561198068349006', '3744', '7500', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[k1nGz]dERP`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_salmon`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('57', '[] Backer', '76561198018544207', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[] Backer`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('58', 'Jonas', '76561198128645226', '7201', '852912', '2', '\"[[`license_cop_air`,0],[`license_cop_swat`,0],[`license_cop_cg`,0]]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,1],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,1],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,1],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,1],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[`arifle_MX_F`,`hgun_P07_snds_F`,[`30Rnd_65x39_caseless_mag`,`16Rnd_9x21_Mag`],`U_Rangemaster`,`V_Rangemaster_belt`,`B_Carryall_cbr`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`NVGoggles`,`Binocular`,`G_Shades_Black`,`H_Booniehat_mcamo`],[``,``,`optic_Arco`],[],[`muzzle_snds_L`,``,``],[`30Rnd_65x39_caseless_mag`,`16Rnd_9x21_Mag`],[`muzzle_snds_H`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`,`30Rnd_65x39_caseless_mag`,`30Rnd_65x39_caseless_mag`],[`ToolKit`,`16Rnd_9x21_Mag`,`16Rnd_9x21_Mag`]]\"', '2', '0', '\"[`Jonas`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemGPS`,`NVGoggles`,`Binocular`,`G_Shades_Black`,`H_Booniehat_tan`],[],[],[],[],[],[`ToolKit`,`ToolKit`,`ToolKit`,`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('59', 'Z4', '76561198076340954', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Z4`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_blue`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('60', 'Brandon', '76561198082002739', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Brandon`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_salmon`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('61', 'Sewi', '76561197982972737', '0', '2000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Sewi`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,`B_Carryall_oli`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`NVGoggles`,`G_Shades_Red`],[],[],[],[],[],[`ToolKit`]]\"', '0');
INSERT INTO players VALUES ('62', 'G. Gordon', '76561198057416294', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`G. Gordon`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('63', 'coresync', '76561198136174074', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`coresync`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('64', 'Surlako', '76561198030873024', '7500', '0', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Surlako`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_salmon`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('65', 'Ractory', '76561198073241131', '0', '2500', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Ractory`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('66', '[NoN]Sallk0', '76561198054962048', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[NoN]Sallk0`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_salmon`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('67', 'Marco', '76561198097414213', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Marco`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('68', 'Goicke', '76561198074303424', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Goicke`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_tricolour`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('69', 'David', '76561198015555755', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`David`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('70', 'Roni', '76561198019273245', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`jus61`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('71', 'hcKR', '76561197966645321', '6250', '0', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`hcKR`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('72', 'Admin', '76561198074750140', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Admin`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('73', 'Darkdevill', '76561198007424871', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Darkdevill`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('74', 'Darksky', '76561198001593731', '5750', '0', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Darksky`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_redwhite`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('75', '[UBLC] Gustavo H.', '76561198116285512', '5992', '0', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`[UBLC] Gustavo H.`]\"', '0', '0', '\"[``,``,[],`U_IG_Guerilla2_3`,``,`B_Carryall_khk`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`H_BandMask_blk`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('76', 'Heinrich', '76561197962788753', '11792', '11750', '0', '\"[]\"', '\"[[`license_civ_driver`,1],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,1],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Heinrich`]\"', '0', '0', '\"[``,``,[],`U_IG_Guerilla2_2`,``,`B_Carryall_oli`,[`ItemMap`,`ItemCompass`,`ItemWatch`,`ItemGPS`,`H_Booniehat_tan`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('77', 'Keshi', '76561198043411663', '10000', '0', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Keshi`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_burgundy`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('78', 'Leutnant', '76561198078869012', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Leutnant`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('79', 'Mr.Chogan', '76561197992304474', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Mr.Chogan`]\"', '0', '0', '\"[``,``,[],`U_C_HunterBody_grn`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');
INSERT INTO players VALUES ('80', 'Hunt3r', '76561198135185943', '0', '10000', '0', '\"[]\"', '\"[]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Hunt3r`]\"', '0', '0', '\"[]\"', '0');
INSERT INTO players VALUES ('81', 'Jokurt', '76561197966451945', '0', '10000', '0', '\"[]\"', '\"[[`license_civ_driver`,0],[`license_civ_air`,0],[`license_civ_heroin`,0],[`license_civ_marijuana`,0],[`license_civ_gang`,0],[`license_civ_boat`,0],[`license_civ_oil`,0],[`license_civ_dive`,0],[`license_civ_truck`,0],[`license_civ_gun`,0],[`license_civ_rebel`,0],[`license_civ_coke`,0],[`license_civ_diamond`,0],[`license_civ_copper`,0],[`license_civ_iron`,0],[`license_civ_sand`,0],[`license_civ_salt`,0],[`license_civ_cement`,0],[`license_civ_home`,0],[`license_civ_silber`,0],[`license_civ_gold`,0]]\"', '\"[]\"', '\"[]\"', '0', '0', '\"[`Jokurt`]\"', '0', '0', '\"[``,``,[],`U_C_Poloshirt_stripped`,``,``,[`ItemMap`,`ItemCompass`,`ItemWatch`],[],[],[],[],[],[]]\"', '0');

-- ----------------------------
-- Table structure for `vehicles`
-- ----------------------------
DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `side` varchar(15) NOT NULL,
  `classname` varchar(32) NOT NULL,
  `type` varchar(12) NOT NULL,
  `pid` varchar(32) NOT NULL,
  `alive` tinyint(1) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `plate` int(20) NOT NULL,
  `color` int(20) NOT NULL,
  `inventory` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `side` (`side`),
  KEY `pid` (`pid`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of vehicles
-- ----------------------------
INSERT INTO vehicles VALUES ('256', 'civ', 'B_Quadbike_01_F', 'Car', '76561198066153753', '1', '0', '828083', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('257', 'civ', 'B_Quadbike_01_F', 'Car', '76561197979236723', '1', '0', '556367', '5', '\"[]\"');
INSERT INTO vehicles VALUES ('258', 'civ', 'B_Quadbike_01_F', 'Car', '76561198065064254', '1', '0', '416635', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('259', 'civ', 'B_Quadbike_01_F', 'Car', '76561198050174817', '1', '0', '944690', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('261', 'civ', 'B_Quadbike_01_F', 'Car', '76561197979236723', '1', '0', '37181', '5', '\"[]\"');
INSERT INTO vehicles VALUES ('262', 'civ', 'C_SUV_01_F', 'Car', '76561198050174817', '1', '0', '576440', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('264', 'med', 'C_SUV_01_F', 'Car', '76561198050174817', '1', '0', '496890', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('265', 'med', 'C_SUV_01_F', 'Car', '76561198066153753', '1', '0', '279698', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('267', 'cop', 'C_Hatchback_01_F', 'Car', '76561198066153753', '1', '0', '81341', '8', '\"[]\"');
INSERT INTO vehicles VALUES ('268', 'civ', 'B_Quadbike_01_F', 'Car', '76561198078264584', '1', '0', '440742', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('270', 'cop', 'C_SUV_01_F', 'Car', '76561198066153753', '1', '0', '429573', '4', '\"[]\"');
INSERT INTO vehicles VALUES ('273', 'civ', 'B_Quadbike_01_F', 'Car', '76561198124879688', '1', '0', '157046', '3', '\"[]\"');
INSERT INTO vehicles VALUES ('275', 'civ', 'B_Quadbike_01_F', 'Car', '76561198081645574', '1', '0', '523888', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('277', 'civ', 'C_Offroad_01_F', 'Car', '76561198124879688', '1', '0', '35204', '3', '\"[]\"');
INSERT INTO vehicles VALUES ('278', 'civ', 'B_Quadbike_01_F', 'Car', '76561198074646183', '1', '0', '73501', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('279', 'civ', 'B_Quadbike_01_F', 'Car', '76561198065632926', '1', '0', '803388', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('280', 'cop', 'C_SUV_01_F', 'Car', '76561197979236723', '1', '0', '904355', '4', '\"[]\"');
INSERT INTO vehicles VALUES ('281', 'cop', 'C_Hatchback_01_sport_F', 'Car', '76561197987010708', '1', '0', '901057', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('283', 'civ', 'C_Hatchback_01_F', 'Car', '76561198081645574', '1', '0', '301036', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('284', 'civ', 'C_Offroad_01_F', 'Car', '76561198012241252', '1', '0', '208308', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('285', 'cop', 'C_Hatchback_01_F', 'Car', '76561198074646183', '1', '0', '64200', '8', '\"[]\"');
INSERT INTO vehicles VALUES ('286', 'civ', 'I_Truck_02_covered_F', 'Car', '76561197987010708', '1', '0', '337194', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('289', 'civ', 'B_Quadbike_01_F', 'Car', '76561197971220567', '1', '0', '302427', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('290', 'civ', 'B_Quadbike_01_F', 'Car', '76561198016821081', '1', '0', '266886', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('291', 'civ', 'B_Truck_01_box_F', 'Car', '76561197979236723', '1', '0', '614668', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('292', 'civ', 'C_Offroad_01_F', 'Car', '76561198016821081', '1', '0', '559749', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('293', 'civ', 'B_Quadbike_01_F', 'Car', '76561198095463114', '1', '0', '601160', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('294', 'civ', 'C_Hatchback_01_F', 'Car', '76561198095463114', '1', '0', '29445', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('295', 'civ', 'B_Quadbike_01_F', 'Car', '76561198033568630', '1', '0', '930007', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('298', 'med', 'C_SUV_01_F', 'Car', '76561198078264584', '1', '0', '376150', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('332', 'civ', 'O_Truck_03_transport_F', 'Car', '76561198078264584', '1', '0', '569582', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('367', 'civ', 'B_G_Offroad_01_F', 'Car', '76561198101092359', '1', '0', '10395', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('373', 'cop', 'B_MRAP_01_F', 'Car', '76561197987010708', '1', '0', '488551', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('374', 'cop', 'C_SUV_01_F', 'Car', '76561197987010708', '1', '0', '550166', '4', '\"[]\"');
INSERT INTO vehicles VALUES ('375', 'cop', 'C_Offroad_01_F', 'Car', '76561197987010708', '1', '0', '982956', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('376', 'cop', 'B_Quadbike_01_F', 'Car', '76561197987010708', '1', '0', '815409', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('377', 'cop', 'C_Hatchback_01_sport_F', 'Car', '76561197979236723', '1', '0', '48770', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('378', 'cop', 'C_Offroad_01_F', 'Car', '76561197979236723', '1', '0', '653178', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('379', 'med', 'C_SUV_01_F', 'Car', '76561198074646183', '1', '0', '829560', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('391', 'civ', 'C_Offroad_01_F', 'Car', '76561197971220567', '1', '0', '802492', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('401', 'civ', 'C_SUV_01_F', 'Car', '76561198078264584', '1', '0', '806653', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('402', 'civ', 'C_Offroad_01_F', 'Car', '76561198033568630', '1', '0', '186266', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('417', 'civ', 'B_Quadbike_01_F', 'Car', '76561198058821513', '1', '0', '8942', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('420', 'med', 'B_Heli_Light_01_F', 'Air', '76561198078264584', '1', '0', '334943', '14', '\"[]\"');
INSERT INTO vehicles VALUES ('424', 'civ', 'C_SUV_01_F', 'Car', '76561198016821081', '1', '0', '476150', '3', '\"[]\"');
INSERT INTO vehicles VALUES ('426', 'civ', 'B_G_Offroad_01_F', 'Car', '76561198078264584', '1', '0', '653665', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('429', 'civ', 'C_Offroad_01_F', 'Car', '76561198128645226', '1', '0', '432131', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('430', 'civ', 'O_Truck_03_device_F', 'Car', '76561198078264584', '1', '0', '114513', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('431', 'civ', 'B_Truck_01_box_F', 'Car', '76561197971220567', '1', '0', '224986', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('432', 'civ', 'B_Truck_01_box_F', 'Car', '76561198078264584', '1', '0', '788200', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('436', 'civ', 'B_Quadbike_01_F', 'Car', '76561197979236723', '1', '0', '961551', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('441', 'med', 'C_SUV_01_F', 'Car', '76561197979236723', '1', '0', '232936', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('442', 'cop', 'C_SUV_01_F', 'Car', '76561198128645226', '1', '0', '192713', '4', '\"[]\"');
INSERT INTO vehicles VALUES ('443', 'med', 'B_Heli_Light_01_F', 'Air', '76561198066153753', '1', '0', '444830', '14', '\"[]\"');
INSERT INTO vehicles VALUES ('444', 'civ', 'C_SUV_01_F', 'Car', '76561197971220567', '1', '0', '803515', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('445', 'civ', 'O_Truck_03_transport_F', 'Car', '76561198066153753', '1', '0', '276533', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('446', 'cop', 'C_Hatchback_01_sport_F', 'Car', '76561197987010708', '1', '0', '465235', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('447', 'civ', 'C_SUV_01_F', 'Car', '76561197971220567', '1', '0', '602128', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('452', 'cop', 'B_Heli_Light_01_F', 'Air', '76561197987010708', '1', '0', '860809', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('453', 'civ', 'B_Heli_Light_01_F', 'Air', '76561197971220567', '1', '0', '416957', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('455', 'med', 'B_Heli_Light_01_F', 'Air', '76561197979236723', '1', '0', '799843', '14', '\"[]\"');
INSERT INTO vehicles VALUES ('456', 'cop', 'C_Offroad_01_F', 'Car', '76561198050174817', '1', '0', '3048', '7', '\"[]\"');
INSERT INTO vehicles VALUES ('457', 'cop', 'C_Hatchback_01_sport_F', 'Car', '76561198050174817', '1', '0', '552569', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('458', 'cop', 'B_Heli_Light_01_F', 'Air', '76561198050174817', '1', '0', '930787', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('459', 'civ', 'B_Truck_01_box_F', 'Car', '76561198128645226', '1', '0', '219467', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('460', 'civ', 'C_Offroad_01_F', 'Car', '76561198050174817', '1', '0', '860583', '6', '\"[]\"');
INSERT INTO vehicles VALUES ('461', 'civ', 'C_Offroad_01_F', 'Car', '76561198050174817', '1', '0', '928271', '5', '\"[]\"');
INSERT INTO vehicles VALUES ('462', 'civ', 'C_SUV_01_F', 'Car', '76561198050174817', '1', '0', '926787', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('463', 'civ', 'C_SUV_01_F', 'Car', '76561197979236723', '1', '0', '263383', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('470', 'civ', 'I_Heli_Transport_02_F', 'Air', '76561197979236723', '1', '0', '269010', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('471', 'civ', 'O_MRAP_02_F', 'Car', '76561197979236723', '1', '0', '927800', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('473', 'cop', 'B_Heli_Transport_01_F', 'Air', '76561198050174817', '1', '0', '895376', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('474', 'cop', 'B_MRAP_01_F', 'Car', '76561198050174817', '1', '0', '711580', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('475', 'cop', 'I_Heli_light_03_unarmed_F', 'Air', '76561198050174817', '1', '0', '821720', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('476', 'civ', 'C_SUV_01_F', 'Car', '76561197979236723', '1', '0', '422684', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('477', 'civ', 'B_Heli_Light_01_F', 'Air', '76561197979236723', '1', '0', '825097', '13', '\"[]\"');
INSERT INTO vehicles VALUES ('478', 'cop', 'C_SUV_01_F', 'Car', '76561198050174817', '1', '0', '392119', '4', '\"[]\"');
INSERT INTO vehicles VALUES ('479', 'civ', 'C_Kart_01_Red_F', 'Car', '76561198078264584', '1', '0', '967618', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('480', 'civ', 'I_Heli_Transport_02_F', 'Air', '76561198074646183', '1', '0', '150536', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('481', 'med', 'B_Heli_Light_01_F', 'Air', '76561197987010708', '1', '0', '434024', '14', '\"[]\"');
INSERT INTO vehicles VALUES ('482', 'civ', 'C_Kart_01_Vrana_F', 'Car', '76561198033568630', '1', '0', '71947', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('483', 'civ', 'C_Kart_01_Blu_F', 'Car', '76561198033568630', '1', '0', '815443', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('484', 'civ', 'C_Kart_01_Fuel_F', 'Car', '76561198033568630', '1', '0', '260128', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('485', 'civ', 'C_Kart_01_Vrana_F', 'Car', '76561197979236723', '1', '0', '418578', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('486', 'civ', 'C_Kart_01_Red_F', 'Car', '76561198128645226', '1', '0', '314697', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('487', 'civ', 'C_Kart_01_Blu_F', 'Car', '76561198128645226', '1', '0', '453590', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('488', 'civ', 'C_Kart_01_Vrana_F', 'Car', '76561198128645226', '1', '0', '897681', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('489', 'civ', 'C_Kart_01_Red_F', 'Car', '76561198128645226', '1', '0', '227422', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('490', 'civ', 'B_Truck_01_covered_F', 'Car', '76561198016821081', '1', '0', '255616', '0', '\"[]\"');
INSERT INTO vehicles VALUES ('491', 'civ', 'C_Offroad_01_F', 'Car', '76561198081645574', '1', '0', '486337', '1', '\"[]\"');
INSERT INTO vehicles VALUES ('492', 'civ', 'B_Quadbike_01_F', 'Car', '76561197966645321', '1', '0', '294832', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('493', 'civ', 'B_Quadbike_01_F', 'Car', '76561198001593731', '1', '0', '953413', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('495', 'civ', 'B_Quadbike_01_F', 'Car', '76561197962788753', '1', '0', '544046', '2', '\"[]\"');
INSERT INTO vehicles VALUES ('496', 'civ', 'B_Quadbike_01_F', 'Car', '76561197962788753', '1', '0', '628723', '2', '\"[]\"');

-- ----------------------------
-- Procedure structure for `deleteDeadVehicles`
-- ----------------------------
DROP PROCEDURE IF EXISTS `deleteDeadVehicles`;
DELIMITER ;;

;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for `resetLifeVehicles`
-- ----------------------------
DROP PROCEDURE IF EXISTS `resetLifeVehicles`;
DELIMITER ;;

;;
DELIMITER ;
